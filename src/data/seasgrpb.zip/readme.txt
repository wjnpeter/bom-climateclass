Bureau of Meteorology - Major Seasonal Rainfall Zones Classification

The major seasonal rainfall zone classification is based on median annual rainfall
(November to April and May to October) and seasonal incidence of rainfall.

The major seasonal rainfall zone ascii file provided is: srngrp.shp
The identifiers, which are shown in the field titled ZONEGRP-NUM, are:  

2 Summer Dominant

4 Arid

6 Summer

10 Uniform

14 Winter Dominant

18 Winter

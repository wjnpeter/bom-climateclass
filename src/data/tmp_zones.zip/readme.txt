
Thermal Climate Zone Classification

The ascii file provided is clim-zones.txt - shows classification groups.

The identifiers, which are shown in the field titled Grid-code, are:
  
Grid-code	Classification
1 		Hot humid summer
2 		Warm humid summer
3 		Hot dry summer, mild winter
4 		Hot dry summer, cold winter
5 		Warm summer, cool winter
6 		Mild warm summer, cold winter

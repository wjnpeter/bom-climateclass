Bureau of Meteorology - Major Classification Groups (based on the koeppen classification system)

The ascii file (kpngrp.txt) shows all classification sub-groups.
The identifiers are shown in the field titled Grid-code.  
The identifiers are:

41 Equatorial

35 Tropical

32 Subtropical

22 Desert

13 Grassland

3 Temperate


